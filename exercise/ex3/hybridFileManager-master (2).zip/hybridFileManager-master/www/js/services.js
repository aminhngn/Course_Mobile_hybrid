angular.module('starter.services', [])

.factory('fileUtil', ['$q', function($q) {
 
  return {
    getPicture: function(options) {
      var q = $q.defer();
      
      navigator.camera.getPicture(function(result) {
        // Do any magic you need
        q.resolve(result);
      }, function(err) {
        q.reject(err);
      }, options);
      
      return q.promise;
    },

    getList: function($scope,directoryEntry){
      var q = $q.defer();

      if( !directoryEntry.isDirectory ) console.log('listDir incorrect type');
      //$.mobile.showPageLoadingMsg(); // show loading message
      
      $scope.currentDir = directoryEntry; // set current directory
      directoryEntry.getParent(function(par){ // success get parent
        $scope.parentDir = par; // set parent directory
        if( ($scope.parentDir.name == 'sdcard' && currentDir.name != 'sdcard') || $scope.parentDir.name != 'sdcard' ) 
          $scope.showBack = true;
      }, function(error){ // error get parent
        console.log('Get parent error: '+error.code);
      });
      
      var directoryReader = directoryEntry.createReader();
      directoryReader.readEntries(function(entries){
        //var dirContent = $scope.dirContent;
        //dirContent.empty();
        
        var dirArr = new Array();
        var fileArr = new Array();
        for(var i=0; i<entries.length; ++i){ // sort entries
          var entry = entries[i];
          if( entry.isDirectory && entry.name[0] != '.' ) dirArr.push(entry);
          else if( entry.isFile && entry.name[0] != '.' ) fileArr.push(entry);
        }
        
        var sortedArr = dirArr.concat(fileArr); // sorted entries
        var uiBlock = ['a','b','c','d'];
        q.resolve(sortedArr);
        //$.mobile.hidePageLoadingMsg(); // hide loading message
      }, function(error){
        console.log('listDir readEntries error: '+error.code);
      });
      return q.promise;
    }
  }
}])

/**
 * A simple example service that returns some data.
 */
.factory('Friends', function() {
  // Might use a resource here that returns a JSON array

  // Some fake testing data
  var friends = [
    { id: 0, name: 'Scruff McGruff' },
    { id: 1, name: 'G.I. Joe' },
    { id: 2, name: 'Miss Frizzle' },
    { id: 3, name: 'Ash Ketchum' }
  ];

  return {
    all: function() {
      return friends;
    },
    get: function(friendId) {
      // Simple index lookup
      return friends[friendId];
    }
  }
});
