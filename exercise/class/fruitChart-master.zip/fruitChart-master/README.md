# IBS Mobile Training course
Hybrid - Exercise 1 - Nguyen Phu Si

3 . Implementation of app using ionic.<br />
  &nbsp;&nbsp;a.  Display a results to chart to ionic frame.<br />
  &nbsp;&nbsp;b.  Input data is list of fresh fruit (orange, apple, mango, strawberry, etc) with some 
  quantities.<br />
  &nbsp;&nbsp;c.  Display different chart to your app. (pie chart, bar chart, etc).<br />
  &nbsp;&nbsp;d.  Hint: use angularjs chart to display in your ionic apps.<br />
    &nbsp;&nbsp;&nbsp;&nbsp;i.  http://jtblin.github.io/angular-chart.js/<br />
    &nbsp;&nbsp;&nbsp;&nbsp;ii.  http://ionicframework.com/docs/<br />
