// Ionic Starter App

// angular.module is a global place for creating, registering and retrieving Angular modules
// 'starter' is the name of this angular module example (also set in a <body> attribute in index.html)
// the 2nd parameter is an array of 'requires'
angular.module('starter', ['ionic','starter.services'])
.config(function($compileProvider){
  $compileProvider.imgSrcSanitizationWhitelist(/^\s*(https?|ftp|mailto|file|tel):/);
})
.controller('MainCtrl', function($scope, fileUtil,$ionicPlatform,$ionicSideMenuDelegate) {

  //$scope.root = null;
  //$scope.currentDir = null;
  //$scope.parentDir = null;
  window.addEventListener('load', function () {
    document.addEventListener('deviceready', onDeviceReady, false);
  }, false);

  function onDeviceReady(){
    $scope.showBack = false;
    
    //$scope.getFileSystem();
    //$scope.clickItemAction();
    window.requestFileSystem(LocalFileSystem.PERSISTENT, 0,onFileSystemSuccess,fail);
    
  }

  $scope.toggleLeft = function() {
    $ionicSideMenuDelegate.toggleLeft();
  };
  
  $ionicPlatform.ready(function() {
    // Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
    // for form inputs)
    if(window.cordova && window.cordova.plugins.Keyboard) {
      cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
    }
    if(window.StatusBar) {
      StatusBar.styleDefault();
    }
    
  });

  var onFileSystemSuccess = function(fileSystem){
    $scope.root = fileSystem.root;
    console.log('$scope.root in funciton'+$scope.root);
    fileUtil.getList($scope,$scope.root).then(function(data){
      $scope.dirContent = data;
      console.log('****data *******'+data);
    });
  };

  var fail = function(evt){ // error get file system
    console.log("File System Error: "+evt.target.error.code);
  };

  

  /* read from file */
  function readFile(fileEntry){
    if( !fileEntry.isFile ) console.log('readFile incorrect type');
    //$.mobile.showPageLoadingMsg(); // show loading message
    
    fileEntry.file(function(file){
      var reader = new FileReader();
      reader.onloadend = function(evt) {
              console.log("Read as data URL");
              console.log(evt.target.result); // show data from file into console
          };
          reader.readAsDataURL(file);
          
          //$.mobile.hidePageLoadingMsg(); // hide loading message
          
          // dialog with file details
          $scope.file_details = file;
          /*
          $('#file_details').html('<p><strong>Name:</strong> '+file.name+
                      '</p><p><strong>Type:</strong> '+file.type+
                      '</p><p><strong>Last Modified:</strong> '+new Date(file.lastModifiedDate)+
                      '</p><p><strong>Size:</strong> '+file.size);
          $('#get_file_details').trigger('click');
          */
    }, function(error){
      console.log(evt.target.error.code);
    });
  };
  /*
  fileUtil.getList($scope,$scope.root).then(function(data){
      $scope.dirContent = data;
      console.log('****data '+data);
    });
  */
})
