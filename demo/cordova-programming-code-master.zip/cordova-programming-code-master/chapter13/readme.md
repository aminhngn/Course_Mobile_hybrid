This folder contains the example source code from chapter 13 of Apache Cordova 3 Programming. 

The Native Plugin folder contains the sample index.html that exercises the Carrier plugin located at https://github.com/johnwargo/cordova-programming-code/tree/master/plugins/carrier.

The Simple Plugin folder contains the sample index.html that exercises the MoL plugin located at https://github.com/johnwargo/cordova-programming-code/tree/master/plugins/mol.