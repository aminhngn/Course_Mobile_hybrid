Apache Cordova 3 Programming
============================

This repository contains the Cordova source code for the application projects highlighted in Apache Cordova 3 Programming (www.cordovaprogramming.com). The application projects included herein were created using Cordova 3.0.

There are a lot of code snippets throughout the book, but all I have published here is the complete applications included in the book.

Folders:

* Chapter 5: Contains the source code for the four HelloWorld applications highlighted in the chapter.
* Chapter 13: Contains the sample applications used to test the Meaning of Life and Carrier plugins highlighted in the chapter.
* Chapter 14: Contains the Compass application highlighted in this chapter.
* plugins: Contains the source code for the Meaning of Life and Carrier plugins.

You can purchase the book on Amazon.com at http://amzn.to/IRhB8C or the publisher's web site at http://www.informit.com/store/apache-cordova-3-programming-9780321957368. 

If you have any questions, you can send me an email through the contact form on www.cordovaprogramming.com.

***

You can find information on many different topics on my personal blog at www.johnwargo.com. Learn about all of my publications at www.johnwargobooks.com. 