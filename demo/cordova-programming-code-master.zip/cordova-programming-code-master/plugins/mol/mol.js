var mol = {
	calculateMOL : function() {
		return 42;
	}
};

module.exports = mol;
