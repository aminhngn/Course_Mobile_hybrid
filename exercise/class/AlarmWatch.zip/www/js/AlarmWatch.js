angular.module('todoDate', ['ionic'])

.controller('TodoDateCtrl', function($scope, $timeout, $ionicModal, $filter) {
	
	$scope.clock = "loading clock..."; // initialise the time variable
    $scope.tickInterval = 1000 //ms

	$scope.setHour=0;
	$scope.setMinute=0;
	$scope.currentHour=0;
	$scope.currentMinute=0;
	//$scope.timeUpMessage="";
	//var s="";
	
    var tick = function() {
        $scope.clock = Date.now() // get the current time
        $timeout(tick, $scope.tickInterval); // reset the timer
		$scope.currentHour = $filter("date")(Date.now(), 'hh');
		$scope.currentMinute = $filter("date")(Date.now(), 'mm');
		if($scope.setHour > 0 && $scope.setMinute > 0)
		{
			if($scope.setHour == $scope.currentHour && $scope.currentMinute == $scope.setMinute)
			{
				$scope.TimeUpModal.show();
				$scope.setHour=0;
				$scope.setMinute=0;
			}
		}
    }

    // Start the timer
    $timeout(tick, $scope.tickInterval);
		
	$scope.fuckingDate = {
		date: new Date()
	};
	
// Create our modal
  $ionicModal.fromTemplateUrl('new-alarm.html', function(modal) {
    $scope.alarmModal = modal;
  }, {
    scope: $scope
  });
  
  $scope.createAlarm = function(alarm) {
	if(alarm.setHour <10)
		alarm.setHour= '0'+alarm.setHour;
	  $scope.setHour=alarm.setHour;
	  if(alarm.setMinute <10)
		alarm.setMinute= '0'+alarm.setMinute;
	  $scope.setMinute=alarm.setMinute;
	  
	  alarm.setHour= "";
	  alarm.setMinute= "";
      $scope.alarmModal.hide();
  };
	// Open our new alarm modal
	$scope.setAlarm = function() {
		$scope.alarmModal.show();
	};
  // Close the new alarm modal
  $scope.closeAlarm = function() {
    $scope.alarmModal.hide();
  };
  
  $ionicModal.fromTemplateUrl('TimeUp.html', function(modal) {
    $scope.TimeUpModal = modal;
  }, {
    scope: $scope
  });
  
  $scope.closeTimeUpModal = function() {
    $scope.TimeUpModal.hide();
  };
})